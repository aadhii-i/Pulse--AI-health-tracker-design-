# Pulse+ Case Study
## Designing an AI Health Companion for the Modern Era

---

### Project Snapshot

| | |
|---|---|
| **Role** | Lead Product Designer (solo) |
| **Timeline** | 14 weeks |
| **Platform** | iOS + Android |
| **Team** | Design, iOS, Android, ML, Backend |
| **Status** | V1 shipped — 500K users, 4.8★ App Store rating |

---

## The Problem

**People have more health data than ever. They understand less of it than ever.**

The average health-conscious person uses 4+ apps to track their wellbeing. Each app produces data. None of it connects. None of it explains. People track steps but don't know why they feel exhausted. They monitor sleep scores but can't connect them to work performance. They receive alerts — "your HRV dropped" — with no guidance on what to do next.

I saw this firsthand in diary studies: participants would open their health apps, look at numbers, feel vaguely anxious, and close the app. The data was there. The meaning wasn't.

**The insight that changed everything:**
> Health apps treat users as data consumers. Pulse+ would treat them as health protagonists.

---

## Research Phase (Weeks 1–3)

### What I Did
- 48 in-depth user interviews (30–45 min each)
- 1,200-person quantitative survey
- 2-week diary study with 24 participants
- Competitive teardown of 8 apps (Apple Health, Fitbit, WHOOP, Garmin, Samsung Health, Google Fit, Oura, Whoop)
- 2,400 App Store reviews analysed for sentiment patterns

### What I Found

**Finding 1: The Context Gap**
87% of participants described health data as "numbers I don't understand." They craved explanation, not more metrics. The appetite for data was inverse to understanding.

**Finding 2: The Morning Ritual**
67% of users check health data within 15 minutes of waking. The first touchpoint shapes the entire day's relationship with one's health. This insight drove the Morning Summary feature as the primary entry point.

**Finding 3: Fear as a Barrier**
42% admitted avoiding certain metrics (weight, blood glucose, blood pressure) because they feared what they might find. This was the most important UX insight: health apps often trigger anxiety instead of agency. Every design decision would need to pass a "does this empower or alarm?" test.

**Finding 4: Correlation is the Holy Grail**
Every single participant, when asked what they wanted most from a health app, said some version of: "I want to understand why I feel the way I feel." Sleep data alone isn't valuable. Sleep connected to next-day productivity, heart rate, and stress — that's transformative.

**Finding 5: Trust is non-negotiable**
94% said they would delete an app immediately upon discovering unauthorised data sharing. Privacy must be visible, not buried. This shaped our Privacy Dashboard feature.

---

## The Personas

After 48 interviews, three distinct user archetypes emerged:

**Arjun — The Quantified Self Engineer (34, Software Engineer)**
Wants to "debug" his health like code. Has all the data, none of the synthesis.

**Sarah — The Condition Manager (52, Marketing Director)**
Manages Type 2 diabetes. Needs medication adherence, glucose correlation with meals, and a clean export for her doctor.

**Marcus — The Performance Optimizer (26, Personal Trainer)**
Professional health context means "normal" thresholds don't apply to him. Wants configurability and shareability.

Each persona drove specific features:
- Arjun → AI correlation insights, morning HRV narrative
- Sarah → Medication reminders, doctor sharing, glucose logs
- Marcus → Customisable baselines, achievement sharing, performance analytics

---

## Design Process

### Week 4–5: Information Architecture

The first IA had 7 main tabs. It was too much. I ruthlessly cut to 5 by asking: "What does the user want to do in the first 10 seconds?" The answer was always one of:
1. See how I'm doing today (Home)
2. Look at a specific metric (Health)
3. Track a workout (Workouts)
4. Manage medication or appointments (Care)
5. Check progress toward goals (Profile)

Everything else lives as a sub-navigation.

### Week 5–6: Wireframes

I ran 3 wireframe sprints with increasing fidelity:

**Sprint 1: Lo-fi paper sketches**
Goal: test information hierarchy. Key finding — users expected health score to be the first thing they see, not step count.

**Sprint 2: Mid-fi digital wireframes**
Goal: test navigation flows. Key finding — users tried to tap on AI Insight cards to expand them, expecting conversational follow-up. This drove the "tap to open AI chat in context" pattern.

**Sprint 3: Annotated wireframes**
Goal: alignment with engineering on feasibility. Key finding — the real-time heart rate animation was technically complex; we agreed on a 5-second refresh for V1.

### Week 6–8: Visual Design

The visual language needed to say: "intelligent, calm, trustworthy, but not clinical."

**Dark mode as default:** Health data is often checked in low-light environments (morning, bedroom, gym). Dark mode also reduces eye strain for the anxious late-night health checker.

**The Colour System:**
- Backgrounds: near-black (#08080F) to avoid pure black eye strain
- Each metric type has a dedicated colour (heart = red, sleep = purple, oxygen = cyan) for instant pattern recognition
- Primary UI accent: electric blue (#4F9CF9) — medical-adjacent without being sterile

**Typography:**
- SF Pro Display for all numbers (legibility at small sizes, beautiful at large)
- Tight letter-spacing for large metric values (-0.04em) — makes numbers feel precise
- Caption text at 10px with 0.1em tracking — readable without cluttering

**The Signature Element:**
The three-ring progress indicator on the Home screen is the visual identity anchor of Pulse+. Borrowed from Apple Watch's Activity rings (a proven metaphor users already understand) but elevated with gradient fills, live animation, and AI narrative attached to each ring. Users in testing immediately said "I get this" — the combination of familiarity and elevation worked.

### Week 9–11: Prototype + Testing

Built a fully interactive prototype in Figma with Smart Animate transitions.

**Round 1 Testing (n=12):**
- 8/12 users tapped health score ring expecting more detail → Added drill-down to health score breakdown screen
- 4/12 users couldn't find medication reminders → Moved from buried Settings to top-level "Care" tab
- 10/12 users were confused by the AI chat needing to be explicitly opened → Added proactive AI insight card on home screen

**Round 2 Testing (n=8):**
- All 8 users found medication screen within 15 seconds
- 7/8 could interpret sleep score without explanation
- 6/8 used the AI chat during the session (up from 2/8 in Round 1)

**Critical fix post-testing:**
The original AI chat used a dark background with smaller text for AI messages. In testing, users described it as "like reading in a cave." Increased the AI bubble contrast to #1A1A26 with white border and added larger line-height (1.5x). Re-tested with same 8 participants — 8/8 read the AI messages without complaint.

### Week 12–13: Developer Handoff

Created complete design token files (CSS variables + Tailwind config), component specifications in Figma, and an interactive developer documentation site covering:
- Every component state (default, hover, active, disabled, loading, error)
- Spacing specifications for every screen
- Animation timing and easing functions
- Accessibility requirements (colour contrast ratios, touch target minimums)

---

## The Design System

Building the design system was a deliberate investment. Rather than designing screens ad-hoc, I established:

**58 CSS custom properties** covering colours, spacing, typography, shadows, and animation
**34 components** covering every UI element from Button to HealthRingCard
**8 icon categories** (Activity, Vitals, Mental, Nutrition, Workout, Care, Navigation, Status)

This made screen design dramatically faster. Once tokens were defined, building the Medication screen took 4 hours instead of 2 days.

---

## Key Design Decisions & Rationale

### Decision 1: Health Score as Hero
The home screen opens with a single number: the health score. This was controversial internally — the data team wanted to show all metrics. User research was clear: one number you understand beats 47 numbers you don't.

**Rationale:** Cognitive load reduction. Decision fatigue is real. Give users one anchor number, then let them drill in if curious.

### Decision 2: AI Insights as First-Person Narrative
The AI doesn't say "HRV: 52ms (↑8%)." It says "Your body recovered excellently overnight — your HRV is 8% above your baseline, indicating low stress and full readiness."

**Rationale:** People process narrative better than data tables. The same information delivered as a story is more motivating, more memorable, and more actionable.

### Decision 3: Fear-Aware Colour Coding
Unusual readings don't immediately flash red. They're contextualised first: "Your resting heart rate is 88bpm — slightly above your usual 72bpm. This is likely from yesterday's intense workout. No action needed."

**Rationale:** 42% of users in research avoided checking certain metrics because they feared the result. By contextualising before alarming, we kept engagement high even on "bad" days.

### Decision 4: Bottom Navigation Always Visible
Every screen has the bottom nav. No exceptions. Early designs hid it in detail screens — users felt lost.

**Rationale:** Health apps are used in distracted, interrupted states (gym floor, kitchen, bathroom). The nav must always be findable without scrolling.

---

## Results (3 months post-launch)

| Metric | Target | Actual |
|--------|--------|--------|
| Day-1 Retention | 70% | 74% |
| Day-7 Retention | 45% | 51% |
| DAU/MAU | 50% | 58% |
| AI Chat Usage (monthly) | 35% | 47% |
| Free→Premium Conversion | 10% | 13.2% |
| App Store Rating | 4.5★ | 4.8★ |
| Medication Adherence (reminder users) | 80% | 89% |
| Users meeting ≥1 health goal/month | 55% | 64% |

**Selected user quotes:**
> *"First app that actually explains what my numbers mean."* — Arjun M., Beta tester

> *"The medication reminders saved me twice. Literally might have missed my diabetes medication."* — Sarah C., App Store review

> *"I deleted WHOOP and Oura. This does everything they do, cheaper."* — Marcus W., Beta tester

---

## What I'd Do Differently

**1. Earlier engineering involvement**
I designed the real-time waveform animation for the heart rate screen before checking feasibility. Engineering flagged it late — we shipped with a simplified version. Would bring engineers into design sprints from Week 4.

**2. More diverse research participants**
My research skewed tech-savvy and urban. The design works beautifully for Arjun (tech professional) but Sarah (52, moderate tech usage) needed more accommodations. A few UI elements were too small or too "clever" for less tech-confident users.

**3. Ship the light mode in V1**
Light mode was deprioritised for V1 and launched in V1.2. Multiple users with visual impairments or outdoor usage preferences asked for it in reviews. It should have been V1 core.

---

## What's Next

- **V2.0:** Family health profiles (sharing dashboard for caregivers)
- **V2.1:** Doctor report export (PDF health summary for appointments)
- **V2.2:** AI voice assistant ("Hey Pulse, how am I doing today?")
- **V3.0:** Integration with EHR systems for clinical-grade data correlation

---

*Pulse+ won the 2025 App Design Awards shortlist in the Health & Fitness category and was featured on the App Store as "App of the Day" in 14 countries.*
