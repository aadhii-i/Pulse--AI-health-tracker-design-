# Pulse+ Design System
## Complete Reference — v1.0

---

## 1. Design Principles

**1. Intelligence over quantity**
Never show data without meaning. Every number has a story.

**2. Calm by default**
Health data can be anxiety-inducing. Default to calm; only escalate when necessary.

**3. One truth per screen**
Each screen answers one question. Home answers "how am I doing today?" Sleep answers "how did I sleep?" The navigation routes between single-purpose screens.

**4. Motion with intention**
Animate what changes. Data loading into view earns animation. Static chrome never moves.

**5. Dark-first**
Dark mode is the primary experience. Light mode is a variant, not an afterthought.

---

## 2. Colour System

### Brand Palette

| Token | Hex | Usage |
|-------|-----|-------|
| `--color-brand-primary` | `#4F9CF9` | Primary CTA, active states, links |
| `--color-brand-secondary` | `#7C6FCD` | Gradient pair, secondary accents |
| `--color-brand-accent` | `#F97316` | Energy, calories, highlights |
| `--color-brand-pulse` | `#EF4444` | Heart metrics, urgency |
| `--color-brand-mint` | `#10B981` | Success, weight, positive change |
| `--color-brand-cyan` | `#06B6D4` | Blood oxygen, water |
| `--color-brand-amber` | `#F59E0B` | Glucose, warnings, achievements |
| `--color-brand-rose` | `#FB7185` | Stress, blood pressure secondary |

### Semantic Colours

```
Success:  #22C55E — Positive health indicators, completed goals
Warning:  #EAB308 — Upcoming doses, mild anomalies
Danger:   #EF4444 — Critical health alerts, missed medications
Info:     #4F9CF9 — General information, AI messages
```

### Background Hierarchy (Dark Mode)

```
Level 0 — Page background:   #08080F (deepest)
Level 1 — Elevated surface:  #111118
Level 2 — Card background:   #1A1A26
Level 3 — Card hover:        #20202E
Level 4 — Input background:  #16161F
Overlay (modals):             rgba(8, 8, 15, 0.85)
Glassmorphism:                rgba(255, 255, 255, 0.04) + blur(20px)
```

### Metric Colour Map

| Metric | Colour | Hex |
|--------|--------|-----|
| Heart Rate | Heart Red | `#EF4444` |
| Blood Pressure | Rose | `#FB7185` |
| Blood Oxygen | Cyan | `#06B6D4` |
| Glucose | Amber | `#F59E0B` |
| Sleep | Deep Violet | `#7C6FCD` |
| Steps | Electric Blue | `#4F9CF9` |
| Calories | Energy Orange | `#F97316` |
| Water | Aqua | `#22D3EE` |
| Weight | Mint Green | `#10B981` |
| Stress | Rose | `#FB7185` |
| HRV | Deep Violet | `#7C6FCD` |

### Accessible Contrast Ratios
All text on backgrounds meets WCAG AA (4.5:1) or AAA (7:1) minimum.

| Text | Background | Ratio | Level |
|------|-----------|-------|-------|
| `#F0F0F8` on `#1A1A26` | 8.9:1 | AAA |
| `#8888A8` on `#1A1A26` | 3.8:1 | AA Large |
| `#4F9CF9` on `#1A1A26` | 4.7:1 | AA |
| `#22C55E` on `#1A1A26` | 4.5:1 | AA |
| `#EF4444` on `#1A1A26` | 4.8:1 | AA |

---

## 3. Typography

### Font Stack
```css
--font-family-display: 'SF Pro Display', -apple-system, 'Helvetica Neue', sans-serif;
--font-family-text:    'SF Pro Text',    -apple-system, 'Helvetica Neue', sans-serif;
--font-family-mono:    'SF Mono', 'Fira Code', monospace;
```

### Type Scale

| Role | Size | Weight | Tracking | Usage |
|------|------|--------|----------|-------|
| Hero Metric | 48–64px | 900 | -0.05em | Large number displays |
| Display | 30–36px | 800 | -0.04em | Health score, key stats |
| Title | 24px | 700 | -0.03em | Screen titles, card headers |
| Section | 17px | 700 | -0.02em | Section headers |
| Body | 16px | 400 | 0 | Paragraph text |
| Body MD | 15px | 400 | 0 | Card body text |
| Body SM | 14px | 400 | 0 | Standard body copy |
| Label | 13px | 500 | 0 | Button labels, UI chrome |
| Caption | 12px | 500 | 0 | Supporting text |
| Micro | 10px | 600 | +0.08em | Category tags, badges |
| Eyebrow | 10px | 700 | +0.12em | Section labels (UPPERCASE) |

---

## 4. Spacing System (8pt Grid)

```
4px  — Internal component gaps (icon to text)
8px  — Tight spacing (badge padding, small gaps)
12px — Medium spacing (list item gaps)
16px — Standard content padding
20px — Card internal padding
24px — Section separation
32px — Major section breaks
40px — Screen-level top padding
```

### Screen Margins
- Horizontal: 16px (content), 22px (headings/prose)
- Card gap: 10–12px
- Section header padding: 14px top / 8px bottom

---

## 5. Component Library

### Button States
Every button has 5 states: Default, Hover, Pressed (scale 0.97), Disabled (opacity 0.4), Loading (spinner replaces label).

### Card Variants
- **Base Card**: `bg-[#1A1A26]` + `border-[rgba(255,255,255,0.07)]` + `rounded-[20-24px]`
- **Gradient Card**: Overlay gradient on base card with matching border
- **Glass Card**: `bg-[rgba(255,255,255,0.04)]` + `backdrop-blur-xl` + subtle border
- **Alert Card**: Semantic background tint + coloured border

### Input States
- Default: `bg-[#16161F]` + `border-[rgba(255,255,255,0.1)]`
- Focus: `border-[#4F9CF9]` + `shadow-[0_0_0_3px_rgba(79,156,249,0.15)]`
- Error: `border-[#EF4444]` + error message below
- Disabled: `opacity-40` + `pointer-events-none`

### Progress Indicators
- **Ring** (ProgressRing): Circular SVG, 5–10px stroke, gradient fill
- **Bar** (ProgressBar): Horizontal, 4–8px height, rounded ends
- **Step** (for onboarding): Pill-shaped dots, active = filled brand colour

---

## 6. Motion Guidelines

### Timing Functions
```css
--ease-default:  cubic-bezier(0.4, 0, 0.2, 1)   /* Material ease */
--ease-out:      cubic-bezier(0, 0, 0.2, 1)       /* Decelerate into position */
--ease-bounce:   cubic-bezier(0.34, 1.56, 0.64, 1) /* Springy entry */
--ease-spring:   cubic-bezier(0.175, 0.885, 0.32, 1.275)
```

### Duration Reference
| Interaction | Duration | Easing |
|-------------|----------|--------|
| Button press feedback | 100ms | ease-default |
| Tooltip/hover | 150ms | ease-out |
| Modal open | 300ms | ease-out |
| Page transition | 350ms | ease-out |
| Health ring animation | 800ms | ease-out |
| Chart line draw | 1000–1500ms | ease-out |
| Health score counter | 1200ms | ease-out |
| Onboarding steps | 400ms | ease-bounce |
| FAB entrance | 500ms | ease-spring |

### Animation Catalogue
```
fadeIn:       opacity 0→1 (250ms)
slideUp:      translateY(20px)→0 + opacity (350ms)
slideDown:    translateY(-20px)→0 + opacity (350ms)
scaleIn:      scale(0.92)→1 + opacity (250ms, ease-bounce)
heartbeat:    scale(1)→1.25→1→1.15→1 (1.5s, infinite)
pulseRing:    opacity 1→0.7→1 (2s, infinite)
drawLine:     stroke-dashoffset animation (1–1.5s)
float:        translateY(0)→(-8px)→(0) (3s, ease-in-out, infinite)
shimmer:      backgroundPosition sweep (1.8s, linear, infinite)
waveDots:     scaleY(1)→1.8→1 (1.2s, staggered 0.2s, infinite)
```

---

## 7. UX Writing Guide

### Voice & Tone
- **Knowledgeable**: We know health science deeply, and we share it accessibly
- **Warm**: We're a supportive companion, not a medical authority
- **Direct**: Short sentences. Active voice. No filler.
- **Empowering**: Every message moves the user toward agency, not anxiety

### Button Labels
```
DO:    "Start workout"       DON'T: "Begin exercise session"
DO:    "Mark as taken"      DON'T: "Confirm medication intake"
DO:    "Book appointment"   DON'T: "Schedule consultation"
DO:    "See full report"    DON'T: "View detailed analytics"
DO:    "Save changes"       DON'T: "Submit"
```

### AI Messages — Principles
1. Lead with the finding, not the data
2. Give the number in context, not raw
3. Always suggest one clear action
4. End with a positive frame when possible

**Before:** "HRV: 52ms — this is 8% above your 30-day mean."
**After:** "Your body recovered excellently overnight. HRV of 52ms means you're well-rested and ready for a challenging workout today."

### Error Messages
```
Network error:   "Can't reach Pulse+ right now. Check your connection and try again."
Sync failed:     "Your data is safely stored on your device. We'll sync as soon as possible."
Biometric fail:  "Face ID didn't work. Try again or use your passcode."
No data:         "No [metric] data yet. Pair your device to start tracking."
```

### Empty States
```
No workouts:  "No workouts this week. Tap + to log your first session."
No meds:      "Your medication schedule is empty. Add medications to get reminders."
No goals:     "Set your first goal and let Pulse+ help you reach it."
No data:      "[Metric] tracking starts as soon as you pair a compatible device."
```

### Notification Copy
```
Morning brief:    "Good morning! Your health score is 84 — up 3 from yesterday. 🌅"
Goal milestone:   "Halfway to your 5K goal! You've run 2.5km this week. 🏃"
Med reminder:     "Time for Metformin 500mg with your lunch. ⏰"
Weekly report:    "Your weekly health summary is ready. Best sleep week in a month! 📊"
Streak:           "12-day streak! You've opened Pulse+ every day this week. 🔥"
```

---

## 8. Accessibility

### Touch Targets
- Minimum: 44×44px (Apple HIG + WCAG 2.5.5)
- Interactive icons: 40×40px with 16px invisible padding
- Bottom nav items: minimum 60px width

### Visual
- All text meets WCAG AA contrast (4.5:1 for normal, 3:1 for large)
- Never convey information by colour alone — always pair with icon or label
- Health alert states use icon + colour + text
- Progress bars have accessible labels (aria-valuenow, aria-valuemax)

### Motion
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```
All animations disabled for reduced-motion preference. Charts show static final state.

### Screen Reader Support
- All metric cards: `role="region"` + `aria-label="Heart Rate: 72 beats per minute"`
- Progress rings: `role="progressbar"` + `aria-valuenow` + `aria-valuemax`
- AI chat: `role="log"` + `aria-live="polite"` for incoming messages
- Bottom nav: `role="navigation"` + `aria-current="page"` for active item

---

## 9. Figma Project Structure

### Page Structure

```
Page 1: 🎯 Cover
  - Project cover with hero mockup
  - Version history
  - Team credits

Page 2: 🔍 Research
  Frames:
  - Research overview summary card
  - 5 key research findings (one frame each)
  - 3 persona cards (Arjun / Sarah / Marcus)
  - Competitive analysis table
  - User journey map
  - Empathy maps (3)

Page 3: 🗺 User Flow
  Frames:
  - Overall navigation map
  - Onboarding flow
  - Health metric drill-down flow
  - Medication management flow
  - AI chat flow
  - Emergency SOS flow
  - Family sharing flow

Page 4: ✏️ Wireframes
  Frames:
  - Lo-fi sketches (photographed, annotated)
  - Mid-fi wireframes (all 65 screens, gray)
  - Annotated wireframes (engineering handoff ready)
  - Iteration comparison (before/after key screens)

Page 5: 🎨 Design System
  Sections:
  - Color System (swatches + usage notes)
  - Typography Scale (all sizes + usage)
  - Spacing System (visual 8pt grid demo)
  - Border Radius Reference
  - Shadow Elevation System
  - Icon Library (8 categories × 24 icons = 192 icons)
  - Illustration Style Guide

Page 6: 🧩 Components
  Sections (all with variants):
  - Atoms: Badge, Button, Input, Checkbox, Toggle, Radio
  - Molecules: MetricCard, AIInsightCard, HealthRingCard, ChatBubble
  - Organisms: BottomNav, StatusBar, SearchBar, MedicationItem
  - Templates: DashboardLayout, DetailLayout, ListLayout
  
  Component structure (per component):
  - Default state
  - Hover / focused state
  - Active / selected state
  - Disabled state
  - Loading state
  - Error state
  - Dark mode variant
  - Light mode variant

Page 7: 🌙 Dark Mode Screens (Primary)
  All 65 screens in dark mode:
  - Onboarding (4 screens)
  - Auth (Login, Signup, OTP, Forgot Password)
  - Profile Setup (4 screens)
  - Home Dashboard
  - Health Summary
  - All vital metric screens (8 screens)
  - Sleep (overview + details)
  - Nutrition (5 screens)
  - Workouts (6 screens)
  - Mental Wellness (4 screens)
  - Medications (3 screens)
  - Doctor & Appointments (4 screens)
  - Lab Reports (3 screens)
  - AI Assistant (2 screens)
  - Health Goals + Achievements
  - Family Sharing (3 screens)
  - Emergency SOS
  - Notifications
  - Settings (5 screens)
  - Profile + Premium
  - Error / Empty States (6 screens)

Page 8: ☀️ Light Mode Screens
  All 65 screens duplicated, light mode applied via Variables

Page 9: 📱 Prototype
  Connected interactive prototype with:
  - All navigation flows connected
  - Smart Animate transitions
  - Gesture interactions (swipe up for health detail)
  - Modal overlays
  - Bottom sheet interactions

Page 10: 🔧 Developer Handoff
  - Design tokens export (CSS + JSON)
  - Component naming conventions
  - Spacing annotation overlays on key screens
  - Animation spec sheets
  - Asset export guide
```

### Figma Variables Setup
```
Collection 1: Colors (dark + light mode)
Collection 2: Typography (size + weight + line-height)
Collection 3: Spacing (all 8pt grid values)
Collection 4: Border Radius
Collection 5: Shadows
Collection 6: Animation (duration + easing strings)
```

### Component Naming Convention
```
Format: [Category]/[Component]/[Variant]/[State]

Examples:
- Atoms/Button/Primary/Default
- Atoms/Button/Primary/Pressed
- Molecules/MetricCard/HeartRate/Normal
- Molecules/MetricCard/HeartRate/Alert
- Organisms/BottomNav/Dark/Home-Active
- Templates/DashboardLayout/Dark
```

---

## 10. Developer Handoff Checklist

### Design Tokens
- [x] CSS custom properties (`tokens.css`)
- [x] Tailwind config (`tailwind.config.js`)
- [ ] JSON format for React Native
- [ ] iOS Swift/SwiftUI tokens
- [ ] Android XML resources

### Assets
- [ ] All icons as individual SVG (192 files)
- [ ] App icon set (all required sizes)
- [ ] Splash screen assets
- [ ] Illustration files (SVG)

### Documentation
- [x] Component specs in Figma
- [x] Animation timing sheet
- [ ] Accessibility annotation overlay
- [x] UX writing guide

### Engineering-Ready
- All spacing in px (annotated)
- All colours as hex (in tokens.css)
- All border radii as px
- All font sizes in rem
- All animations as keyframe definitions
