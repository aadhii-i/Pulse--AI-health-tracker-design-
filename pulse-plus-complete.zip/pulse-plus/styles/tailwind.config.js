/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
    './screens/**/*.html',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',

  theme: {
    extend: {

      /* ── Colors ──────────────────────────────────────────── */
      colors: {
        brand: {
          primary:   '#4F9CF9',
          secondary: '#7C6FCD',
          accent:    '#F97316',
          pulse:     '#EF4444',
          mint:      '#10B981',
          cyan:      '#06B6D4',
          amber:     '#F59E0B',
          rose:      '#FB7185',
        },
        bg: {
          base:      '#08080F',
          elevated:  '#111118',
          card:      '#1A1A26',
          'card-hover': '#20202E',
          input:     '#16161F',
          glass:     'rgba(255,255,255,0.04)',
          'glass-strong': 'rgba(255,255,255,0.08)',
        },
        border: {
          subtle:    'rgba(255,255,255,0.06)',
          default:   'rgba(255,255,255,0.10)',
          strong:    'rgba(255,255,255,0.16)',
          focus:     '#4F9CF9',
        },
        text: {
          primary:   '#F0F0F8',
          secondary: '#8888A8',
          tertiary:  '#55556A',
          disabled:  '#3A3A4A',
          inverse:   '#08080F',
        },
        metric: {
          heart:     '#EF4444',
          bp:        '#FB7185',
          oxygen:    '#06B6D4',
          glucose:   '#F59E0B',
          sleep:     '#7C6FCD',
          steps:     '#4F9CF9',
          calories:  '#F97316',
          water:     '#22D3EE',
          weight:    '#10B981',
          stress:    '#FB7185',
          hrv:       '#7C6FCD',
        },
        state: {
          success:         '#22C55E',
          'success-muted': 'rgba(34,197,94,0.15)',
          warning:         '#EAB308',
          'warning-muted': 'rgba(234,179,8,0.15)',
          danger:          '#EF4444',
          'danger-muted':  'rgba(239,68,68,0.15)',
          info:            '#4F9CF9',
          'info-muted':    'rgba(79,156,249,0.15)',
        },
      },

      /* ── Typography ──────────────────────────────────────── */
      fontFamily: {
        display: ['"SF Pro Display"', '-apple-system', '"Helvetica Neue"', 'sans-serif'],
        body:    ['"SF Pro Text"', '-apple-system', '"Helvetica Neue"', 'sans-serif'],
        mono:    ['"SF Mono"', '"Fira Code"', 'monospace'],
        sans:    ['-apple-system', '"Helvetica Neue"', 'sans-serif'],
      },

      fontSize: {
        'xs':  ['0.625rem', { lineHeight: '1rem' }],
        'sm':  ['0.75rem',  { lineHeight: '1.125rem' }],
        'md':  ['0.875rem', { lineHeight: '1.375rem' }],
        'base': ['1rem',    { lineHeight: '1.5rem' }],
        'lg':  ['1.125rem', { lineHeight: '1.625rem' }],
        'xl':  ['1.25rem',  { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem',   { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.375rem' }],
        '4xl': ['2.25rem',  { lineHeight: '2.75rem' }],
        '5xl': ['3rem',     { lineHeight: '1.15' }],
        '6xl': ['3.75rem',  { lineHeight: '1.1' }],
      },

      letterSpacing: {
        tighter: '-0.04em',
        tight:   '-0.02em',
        normal:  '0',
        wide:    '0.04em',
        wider:   '0.08em',
        widest:  '0.12em',
      },

      /* ── Spacing (8pt base) ──────────────────────────────── */
      spacing: {
        '0.5': '0.125rem',  /* 2px  */
        '1':   '0.25rem',   /* 4px  */
        '1.5': '0.375rem',  /* 6px  */
        '2':   '0.5rem',    /* 8px  */
        '3':   '0.75rem',   /* 12px */
        '4':   '1rem',      /* 16px */
        '5':   '1.25rem',   /* 20px */
        '6':   '1.5rem',    /* 24px */
        '7':   '1.75rem',   /* 28px */
        '8':   '2rem',      /* 32px */
        '9':   '2.25rem',   /* 36px */
        '10':  '2.5rem',    /* 40px */
        '11':  '2.75rem',   /* 44px */
        '12':  '3rem',      /* 48px */
        '14':  '3.5rem',    /* 56px */
        '16':  '4rem',      /* 64px */
        '18':  '4.5rem',    /* 72px */
        '20':  '5rem',      /* 80px */
        '24':  '6rem',      /* 96px */
        '32':  '8rem',      /* 128px */

        /* App-specific */
        'status-bar': '44px',
        'nav-bottom': '80px',
        'fab':        '56px',
      },

      /* ── Border Radius ───────────────────────────────────── */
      borderRadius: {
        'none': '0',
        'xs':   '0.25rem',   /* 4px  */
        'sm':   '0.5rem',    /* 8px  */
        'md':   '0.75rem',   /* 12px */
        'lg':   '1rem',      /* 16px */
        'xl':   '1.25rem',   /* 20px */
        '2xl':  '1.5rem',    /* 24px */
        '3xl':  '2rem',      /* 32px */
        '4xl':  '2.5rem',    /* 40px */
        'full': '9999px',
      },

      /* ── Box Shadow ──────────────────────────────────────── */
      boxShadow: {
        'xs':         '0 1px 2px rgba(0,0,0,0.4)',
        'sm':         '0 2px 8px rgba(0,0,0,0.5)',
        'md':         '0 4px 16px rgba(0,0,0,0.5)',
        'lg':         '0 8px 32px rgba(0,0,0,0.6)',
        'xl':         '0 16px 48px rgba(0,0,0,0.7)',
        'card':       '0 2px 12px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.06)',
        'glow-blue':  '0 0 24px rgba(79,156,249,0.4)',
        'glow-green': '0 0 24px rgba(16,185,129,0.35)',
        'glow-red':   '0 0 24px rgba(239,68,68,0.35)',
        'glow-purple':'0 0 24px rgba(124,111,205,0.35)',
        'fab':        '0 8px 24px rgba(79,156,249,0.4)',
        'none':       'none',
      },

      /* ── Animation ───────────────────────────────────────── */
      transitionTimingFunction: {
        'bounce':  'cubic-bezier(0.34, 1.56, 0.64, 1)',
        'spring':  'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
        'smooth':  'cubic-bezier(0.4, 0, 0.2, 1)',
      },

      transitionDuration: {
        '0':   '0ms',
        '75':  '75ms',
        '150': '150ms',
        '250': '250ms',
        '350': '350ms',
        '400': '400ms',
        '600': '600ms',
      },

      keyframes: {
        'fade-in': {
          from: { opacity: '0' },
          to:   { opacity: '1' },
        },
        'slide-up': {
          from: { transform: 'translateY(20px)', opacity: '0' },
          to:   { transform: 'translateY(0)',    opacity: '1' },
        },
        'slide-down': {
          from: { transform: 'translateY(-20px)', opacity: '0' },
          to:   { transform: 'translateY(0)',     opacity: '1' },
        },
        'scale-in': {
          from: { transform: 'scale(0.92)', opacity: '0' },
          to:   { transform: 'scale(1)',    opacity: '1' },
        },
        'pulse-ring': {
          '0%, 100%': { transform: 'scale(1)',    opacity: '1' },
          '50%':      { transform: 'scale(1.05)', opacity: '0.85' },
        },
        'heartbeat': {
          '0%, 100%': { transform: 'scale(1)' },
          '14%':      { transform: 'scale(1.3)' },
          '28%':      { transform: 'scale(1)' },
          '42%':      { transform: 'scale(1.2)' },
          '56%':      { transform: 'scale(1)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%':      { transform: 'translateY(-8px)' },
        },
        'shimmer': {
          from: { backgroundPosition: '-200% 0' },
          to:   { backgroundPosition: '200% 0' },
        },
        'spin-slow': {
          from: { transform: 'rotate(0deg)' },
          to:   { transform: 'rotate(360deg)' },
        },
        'wave': {
          '0%, 60%, 100%': { transform: 'initial' },
          '30%':           { transform: 'translateY(-8px)' },
        },
      },

      animation: {
        'fade-in':    'fade-in 0.25s ease-out',
        'slide-up':   'slide-up 0.35s cubic-bezier(0,0,0.2,1)',
        'slide-down': 'slide-down 0.35s cubic-bezier(0,0,0.2,1)',
        'scale-in':   'scale-in 0.25s cubic-bezier(0.34,1.56,0.64,1)',
        'pulse-ring': 'pulse-ring 2s ease-in-out infinite',
        'heartbeat':  'heartbeat 1.5s ease-in-out infinite',
        'float':      'float 3s ease-in-out infinite',
        'shimmer':    'shimmer 2s linear infinite',
        'spin-slow':  'spin-slow 8s linear infinite',
      },

      /* ── Backdrop Blur ───────────────────────────────────── */
      backdropBlur: {
        'xs': '4px',
        'sm': '8px',
        'md': '16px',
        'lg': '24px',
        'xl': '40px',
      },

      /* ── Screen Sizes ────────────────────────────────────── */
      screens: {
        'mobile-sm': '320px',
        'mobile':    '390px',
        'tablet':    '768px',
        'desktop':   '1024px',
        'wide':      '1280px',
      },
    },
  },

  plugins: [
    /* Custom component utilities */
    function({ addComponents, theme }) {
      addComponents({
        '.card-base': {
          background: 'var(--color-bg-card)',
          borderRadius: theme('borderRadius.2xl'),
          border: '1px solid var(--color-border-subtle)',
          boxShadow: theme('boxShadow.card'),
          padding: theme('spacing.5'),
        },
        '.metric-label': {
          fontSize: theme('fontSize.xs')[0],
          fontWeight: theme('fontWeight.semibold'),
          letterSpacing: theme('letterSpacing.widest'),
          textTransform: 'uppercase',
          color: 'var(--color-text-secondary)',
        },
        '.metric-value': {
          fontSize: theme('fontSize.3xl')[0],
          fontWeight: theme('fontWeight.bold'),
          letterSpacing: theme('letterSpacing.tighter'),
          color: 'var(--color-text-primary)',
          lineHeight: '1',
        },
        '.btn-primary': {
          background: 'linear-gradient(135deg, #4F9CF9 0%, #7C6FCD 100%)',
          color: '#FFFFFF',
          fontWeight: theme('fontWeight.semibold'),
          borderRadius: theme('borderRadius.full'),
          height: '52px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 16px rgba(79,156,249,0.35)',
          transition: 'all 0.2s cubic-bezier(0.4,0,0.2,1)',
          '&:active': { transform: 'scale(0.97)' },
        },
        '.glass-card': {
          background: 'rgba(255,255,255,0.04)',
          backdropFilter: 'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: theme('borderRadius.2xl'),
        },
      })
    },
  ],
}
