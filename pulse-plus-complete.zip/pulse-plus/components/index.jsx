/**
 * Pulse+ — React Component Library
 * AI-Powered Health Tracker
 * All components use Tailwind CSS + CSS custom properties from tokens.css
 */

import React, { useState, useEffect, useRef } from 'react'

// ═══════════════════════════════════════════════════════════════
// DESIGN TOKEN HELPERS
// ═══════════════════════════════════════════════════════════════

export const METRIC_COLORS = {
  heartRate:   '#EF4444',
  bloodOxygen: '#06B6D4',
  bloodPressure: '#FB7185',
  glucose:     '#F59E0B',
  sleep:       '#7C6FCD',
  steps:       '#4F9CF9',
  calories:    '#F97316',
  water:       '#22D3EE',
  weight:      '#10B981',
  stress:      '#FB7185',
  hrv:         '#7C6FCD',
}

export const GRADIENTS = {
  primary:  'linear-gradient(135deg, #4F9CF9 0%, #7C6FCD 100%)',
  health:   'linear-gradient(135deg, #10B981 0%, #06B6D4 100%)',
  energy:   'linear-gradient(135deg, #F97316 0%, #EF4444 100%)',
  sleep:    'linear-gradient(135deg, #7C6FCD 0%, #312E81 100%)',
  calm:     'linear-gradient(135deg, #06B6D4 0%, #4F9CF9 100%)',
}

// ═══════════════════════════════════════════════════════════════
// ATOMS
// ═══════════════════════════════════════════════════════════════

/**
 * Badge — contextual status labels
 * @param {string} variant - 'blue' | 'green' | 'orange' | 'red' | 'purple' | 'gray'
 */
export const Badge = ({ children, variant = 'blue', className = '' }) => {
  const variants = {
    blue:   'bg-[rgba(79,156,249,0.15)] text-[#4F9CF9] border border-[rgba(79,156,249,0.25)]',
    green:  'bg-[rgba(16,185,129,0.15)] text-[#10B981] border border-[rgba(16,185,129,0.25)]',
    orange: 'bg-[rgba(249,115,22,0.15)] text-[#F97316] border border-[rgba(249,115,22,0.25)]',
    red:    'bg-[rgba(239,68,68,0.15)]  text-[#EF4444] border border-[rgba(239,68,68,0.25)]',
    purple: 'bg-[rgba(124,111,205,0.15)] text-[#7C6FCD] border border-[rgba(124,111,205,0.25)]',
    gray:   'bg-[rgba(255,255,255,0.07)] text-[#8888A8] border border-[rgba(255,255,255,0.1)]',
    gold:   'bg-[rgba(245,158,11,0.15)] text-[#F59E0B] border border-[rgba(245,158,11,0.25)]',
  }
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full
      text-[10px] font-semibold tracking-wide uppercase ${variants[variant]} ${className}`}>
      {children}
    </span>
  )
}

/**
 * Button — primary interaction element
 * @param {string} variant - 'primary' | 'secondary' | 'ghost' | 'danger'
 * @param {string} size - 'sm' | 'md' | 'lg'
 */
export const Button = ({
  children, variant = 'primary', size = 'md', onClick,
  disabled = false, fullWidth = false, icon, className = '',
  ...props
}) => {
  const sizes = {
    sm: 'h-9 px-4 text-sm',
    md: 'h-12 px-6 text-base',
    lg: 'h-14 px-8 text-lg',
  }
  const variants = {
    primary: 'text-white shadow-[0_4px_16px_rgba(79,156,249,0.35)] active:scale-[0.97]',
    secondary: 'bg-[rgba(255,255,255,0.08)] text-[#F0F0F8] border border-[rgba(255,255,255,0.1)] hover:bg-[rgba(255,255,255,0.12)]',
    ghost: 'bg-transparent text-[#4F9CF9] hover:bg-[rgba(79,156,249,0.08)]',
    danger: 'bg-[rgba(239,68,68,0.15)] text-[#EF4444] border border-[rgba(239,68,68,0.2)] hover:bg-[rgba(239,68,68,0.25)]',
  }
  const isPrimary = variant === 'primary'
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        inline-flex items-center justify-center gap-2 rounded-full font-semibold
        transition-all duration-200 select-none cursor-pointer
        ${sizes[size]} ${variants[variant]}
        ${fullWidth ? 'w-full' : ''}
        ${disabled ? 'opacity-40 pointer-events-none' : ''}
        ${className}
      `}
      style={isPrimary ? { background: GRADIENTS.primary } : undefined}
      {...props}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </button>
  )
}

/**
 * ProgressRing — circular SVG progress indicator
 */
export const ProgressRing = ({
  value = 0, max = 100, size = 80, strokeWidth = 8,
  gradient, color = '#4F9CF9', label, sublabel, className = ''
}) => {
  const radius = (size - strokeWidth * 2) / 2
  const circumference = 2 * Math.PI * radius
  const progress = Math.min(value / max, 1)
  const strokeDashoffset = circumference * (1 - progress)
  const gradId = `ring-grad-${Math.random().toString(36).substr(2, 6)}`

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}
         style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        {gradient && (
          <defs>
            <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={gradient[0]} />
              <stop offset="100%" stopColor={gradient[1]} />
            </linearGradient>
          </defs>
        )}
        {/* Track */}
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none"
          stroke={color}
          strokeOpacity={0.15}
          strokeWidth={strokeWidth}
        />
        {/* Progress */}
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none"
          stroke={gradient ? `url(#${gradId})` : color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          style={{ transition: 'stroke-dashoffset 0.8s cubic-bezier(0.4,0,0.2,1)' }}
        />
      </svg>
      {(label !== undefined || sublabel !== undefined) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {label !== undefined && (
            <span className="font-bold text-[#F0F0F8] leading-none" style={{ fontSize: size * 0.22 }}>
              {label}
            </span>
          )}
          {sublabel && (
            <span className="text-[#8888A8] mt-0.5" style={{ fontSize: size * 0.13 }}>
              {sublabel}
            </span>
          )}
        </div>
      )}
    </div>
  )
}

/**
 * ProgressBar — horizontal progress indicator
 */
export const ProgressBar = ({
  value = 0, max = 100, color, gradient, height = 6, className = ''
}) => {
  const pct = Math.min((value / max) * 100, 100)
  return (
    <div className={`rounded-full overflow-hidden bg-[rgba(255,255,255,0.07)] ${className}`}
         style={{ height }}>
      <div
        className="h-full rounded-full transition-all duration-700 ease-out"
        style={{
          width: `${pct}%`,
          background: gradient
            ? `linear-gradient(90deg, ${gradient[0]}, ${gradient[1]})`
            : color || '#4F9CF9',
        }}
      />
    </div>
  )
}

/**
 * Sparkline — mini SVG line chart
 */
export const Sparkline = ({ data = [], color = '#4F9CF9', width = 80, height = 28 }) => {
  if (data.length < 2) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const pad = 2

  const points = data.map((v, i) => {
    const x = pad + (i / (data.length - 1)) * (width - pad * 2)
    const y = pad + (1 - (v - min) / range) * (height - pad * 2)
    return `${x},${y}`
  }).join(' ')

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <defs>
        <linearGradient id={`spark-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.3} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

// ═══════════════════════════════════════════════════════════════
// MOLECULES
// ═══════════════════════════════════════════════════════════════

/**
 * MetricCard — single health metric display card
 */
export const MetricCard = ({
  label, value, unit, change, changePositive = true,
  color = '#4F9CF9', gradient, icon, sparkData, onClick, className = ''
}) => {
  return (
    <div
      onClick={onClick}
      className={`relative p-4 rounded-[20px] bg-[#1A1A26] border border-[rgba(255,255,255,0.07)]
        overflow-hidden cursor-pointer transition-all duration-200 hover:bg-[#20202E]
        active:scale-[0.97] ${className}`}
    >
      {/* Bottom accent bar */}
      <div
        className="absolute bottom-0 left-0 right-0 h-[3px] rounded-b-[20px]"
        style={{ background: gradient ? `linear-gradient(90deg, ${gradient[0]}, ${gradient[1]})` : color }}
      />

      <div className="text-xl mb-2">{icon}</div>
      <div className="text-[10px] font-semibold tracking-[0.08em] uppercase text-[#8888A8]">{label}</div>
      <div className="flex items-baseline gap-1 mt-1">
        <span className="text-2xl font-extrabold tracking-tight text-[#F0F0F8] leading-none">
          {value}
        </span>
        {unit && <span className="text-xs font-medium text-[#55556A]">{unit}</span>}
      </div>
      {change && (
        <div className={`text-[11px] mt-1 font-medium ${changePositive ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
          {changePositive ? '↑' : '↓'} {change}
        </div>
      )}
      {sparkData && (
        <div className="mt-2">
          <Sparkline data={sparkData} color={color} width={120} height={28} />
        </div>
      )}
    </div>
  )
}

/**
 * HealthRingCard — triple-ring activity summary
 */
export const HealthRingCard = ({ move, exercise, stand, className = '' }) => {
  const rings = [
    { label: 'Move', value: move.value, max: move.max, unit: 'kcal', gradient: ['#F97316', '#EF4444'] },
    { label: 'Exercise', value: exercise.value, max: exercise.max, unit: 'min', gradient: ['#22C55E', '#10B981'] },
    { label: 'Stand', value: stand.value, max: stand.max, unit: 'hr', gradient: ['#06B6D4', '#22D3EE'] },
  ]

  return (
    <div className={`p-4 rounded-[20px] bg-[#1A1A26] border border-[rgba(255,255,255,0.07)] ${className}`}>
      <div className="flex justify-between items-center mb-4">
        <span className="text-[15px] font-bold">Today's Progress</span>
        <span className="text-xs text-[#4F9CF9] font-medium">View all →</span>
      </div>
      <div className="space-y-3">
        {rings.map((ring) => {
          const pct = Math.round((ring.value / ring.max) * 100)
          return (
            <div key={ring.label} className="flex items-center gap-3">
              <ProgressRing
                value={ring.value} max={ring.max}
                size={36} strokeWidth={5}
                gradient={ring.gradient}
              />
              <div className="flex-1">
                <div className="text-xs text-[#8888A8]">
                  {ring.label} · {ring.value.toLocaleString()} / {ring.max.toLocaleString()} {ring.unit}
                </div>
                <ProgressBar
                  value={ring.value} max={ring.max}
                  gradient={ring.gradient}
                  height={5}
                  className="mt-1.5"
                />
              </div>
              <div
                className="text-xs font-bold min-w-[32px] text-right"
                style={{ color: ring.gradient[0] }}
              >{pct}%</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/**
 * AIInsightCard — AI-generated health recommendation
 */
export const AIInsightCard = ({ insight, action, onAction, className = '' }) => {
  return (
    <div className={`p-4 rounded-[20px] border border-[rgba(79,156,249,0.2)]
      bg-gradient-to-br from-[rgba(79,156,249,0.08)] to-[rgba(124,111,205,0.08)] ${className}`}>
      <div className="flex gap-3 items-start">
        <div className="w-9 h-9 rounded-[10px] shrink-0 flex items-center justify-center shadow-[0_4px_12px_rgba(79,156,249,0.3)]"
             style={{ background: GRADIENTS.primary }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"
              fill="white" opacity=".8"/>
            <path d="M12 7v5l3 3" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </div>
        <div className="flex-1">
          <div className="text-[10px] font-semibold tracking-widest uppercase text-[#4F9CF9] mb-1">
            AI Insight
          </div>
          <p className="text-[13px] leading-relaxed text-[#C8C8E0]">
            {insight}
          </p>
          {action && (
            <button
              onClick={onAction}
              className="mt-2.5 text-xs font-semibold text-[#4F9CF9] flex items-center gap-1"
            >
              {action} →
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

/**
 * SleepStageChart — horizontal bar breakdown of sleep stages
 */
export const SleepStageChart = ({ stages, className = '' }) => {
  const STAGE_COLORS = {
    deep:  '#7C6FCD',
    rem:   '#4F9CF9',
    light: '#06B6D4',
    awake: '#3A3A4A',
  }
  const total = stages.reduce((sum, s) => sum + s.minutes, 0)

  return (
    <div className={className}>
      {/* Visual bar */}
      <div className="flex h-3 rounded-full overflow-hidden mb-3">
        {stages.map((stage) => (
          <div
            key={stage.key}
            style={{
              width: `${(stage.minutes / total) * 100}%`,
              background: STAGE_COLORS[stage.key],
            }}
          />
        ))}
      </div>
      {/* Legend */}
      <div className="space-y-2">
        {stages.map((stage) => {
          const pct = Math.round((stage.minutes / total) * 100)
          const hrs = Math.floor(stage.minutes / 60)
          const mins = stage.minutes % 60
          return (
            <div key={stage.key} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-sm shrink-0"
                   style={{ background: STAGE_COLORS[stage.key] }} />
              <span className="text-[13px] font-medium flex-1">{stage.label}</span>
              <div className="w-28 mr-2">
                <ProgressBar value={stage.minutes} max={total}
                  color={STAGE_COLORS[stage.key]} height={4} />
              </div>
              <span className="text-[11px] text-[#8888A8] w-10 text-right">
                {hrs > 0 ? `${hrs}h ` : ''}{mins}m
              </span>
              <span className="text-[11px] font-semibold w-8 text-right"
                    style={{ color: STAGE_COLORS[stage.key] }}>
                {pct}%
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/**
 * MedicationItem — single medication row
 */
export const MedicationItem = ({
  name, dosage, instructions, time, status,
  onTaken, className = ''
}) => {
  const statusConfig = {
    taken:    { icon: '✓', color: '#22C55E', bg: 'rgba(34,197,94,0.1)' },
    upcoming: { icon: '○', color: '#F59E0B', bg: 'rgba(245,158,11,0.1)' },
    missed:   { icon: '✕', color: '#EF4444', bg: 'rgba(239,68,68,0.1)' },
    pending:  { icon: '—', color: '#55556A', bg: 'transparent' },
  }
  const s = statusConfig[status] || statusConfig.pending

  return (
    <div className={`flex items-center gap-3 p-4 rounded-[18px] bg-[#1A1A26]
      border border-[rgba(255,255,255,0.07)] ${className}`}>
      <div className="w-11 h-11 rounded-[13px] flex items-center justify-center text-xl shrink-0"
           style={{ background: 'rgba(79,156,249,0.1)' }}>
        💊
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[15px] font-semibold truncate">{name}</div>
        <div className="text-xs text-[#8888A8] mt-0.5">{dosage} · {instructions}</div>
        <div className="text-xs mt-0.5" style={{ color: s.color }}>{time}</div>
      </div>
      <div
        className="text-lg cursor-pointer"
        style={{ color: s.color }}
        onClick={status === 'upcoming' ? onTaken : undefined}
      >
        {s.icon}
      </div>
    </div>
  )
}

/**
 * ChatBubble — AI assistant conversation bubble
 */
export const ChatBubble = ({ role = 'ai', children, timestamp }) => {
  const isUser = role === 'user'
  return (
    <div className={`flex gap-2 items-end ${isUser ? 'flex-row-reverse' : ''}`}>
      {/* Avatar */}
      {!isUser && (
        <div className="w-7 h-7 rounded-[9px] shrink-0 mb-1 flex items-center justify-center"
             style={{ background: GRADIENTS.primary }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"
              fill="white" opacity=".8"/>
          </svg>
        </div>
      )}
      {isUser && (
        <div className="w-7 h-7 rounded-full shrink-0 mb-1 flex items-center justify-center
          text-xs font-bold text-white" style={{ background: GRADIENTS.primary }}>
          AJ
        </div>
      )}
      <div className={`max-w-[78%]`}>
        <div className={`
          px-3.5 py-2.5 text-[13px] leading-relaxed
          ${isUser
            ? 'text-white rounded-[18px] rounded-br-[4px]'
            : 'text-[#E0E0F0] bg-[#1A1A26] border border-[rgba(255,255,255,0.07)] rounded-[18px] rounded-bl-[4px]'
          }
        `}
        style={isUser ? { background: GRADIENTS.primary } : undefined}>
          {children}
        </div>
        {timestamp && (
          <div className={`text-[9px] text-[#55556A] mt-1 ${isUser ? 'text-right' : ''}`}>
            {timestamp}
          </div>
        )}
      </div>
    </div>
  )
}

/**
 * TypingIndicator — animated dots for AI "thinking"
 */
export const TypingIndicator = () => (
  <div className="flex gap-2 items-end">
    <div className="w-7 h-7 rounded-[9px] shrink-0 flex items-center justify-center"
         style={{ background: GRADIENTS.primary }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"
          fill="white" opacity=".8"/>
      </svg>
    </div>
    <div className="px-4 py-3 bg-[#1A1A26] border border-[rgba(255,255,255,0.07)] rounded-[18px] rounded-bl-[4px]">
      <div className="flex gap-1">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="w-1.5 h-1.5 rounded-full bg-[#8888A8]"
            style={{
              animation: 'wave 1.2s ease-in-out infinite',
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </div>
    </div>
  </div>
)

/**
 * GoalCard — health goal progress display
 */
export const GoalCard = ({
  title, subtitle, current, target, unit,
  gradient = ['#4F9CF9', '#7C6FCD'], icon, daysLeft, className = ''
}) => {
  const pct = Math.round((current / target) * 100)
  return (
    <div className={`flex items-center gap-3 p-4 rounded-[18px] bg-[#1A1A26]
      border border-[rgba(255,255,255,0.07)] ${className}`}>
      <div className="w-11 h-11 rounded-[14px] flex items-center justify-center text-xl shrink-0"
           style={{ background: `rgba(${parseInt(gradient[0].slice(1,3),16)},${parseInt(gradient[0].slice(3,5),16)},${parseInt(gradient[0].slice(5,7),16)},0.12)` }}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[14px] font-semibold truncate">{title}</div>
        <div className="text-xs text-[#8888A8] mt-0.5">{subtitle}</div>
        <ProgressBar value={current} max={target} gradient={gradient} height={5} className="mt-2" />
      </div>
      <div className="text-[14px] font-bold shrink-0" style={{ color: gradient[0] }}>
        {pct}%
      </div>
    </div>
  )
}

/**
 * HealthScoreRing — the main hero health score component
 */
export const HealthScoreRing = ({ score = 84, change = 3, size = 180 }) => {
  const pct = score / 100
  const stroke = 10
  const r1 = size / 2 - stroke - 2
  const r2 = r1 - stroke - 6
  const r3 = r2 - stroke - 6
  const c1 = 2 * Math.PI * r1
  const c2 = 2 * Math.PI * r2
  const c3 = 2 * Math.PI * r3

  return (
    <div className="relative inline-flex items-center justify-center"
         style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <defs>
          <linearGradient id="hsg1" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#4F9CF9"/>
            <stop offset="100%" stopColor="#7C6FCD"/>
          </linearGradient>
          <linearGradient id="hsg2" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#10B981"/>
            <stop offset="100%" stopColor="#06B6D4"/>
          </linearGradient>
          <linearGradient id="hsg3" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#F97316"/>
            <stop offset="100%" stopColor="#EF4444"/>
          </linearGradient>
        </defs>
        {/* Outer ring (Activity) */}
        <circle cx={size/2} cy={size/2} r={r1} fill="none" stroke="rgba(79,156,249,0.12)" strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r1} fill="none" stroke="url(#hsg1)" strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={c1} strokeDashoffset={c1 * (1 - pct * 0.82)}/>
        {/* Middle ring (Health) */}
        <circle cx={size/2} cy={size/2} r={r2} fill="none" stroke="rgba(16,185,129,0.12)" strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r2} fill="none" stroke="url(#hsg2)" strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={c2} strokeDashoffset={c2 * (1 - pct * 0.91)}/>
        {/* Inner ring (Wellness) */}
        <circle cx={size/2} cy={size/2} r={r3} fill="none" stroke="rgba(249,115,22,0.12)" strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r3} fill="none" stroke="url(#hsg3)" strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={c3} strokeDashoffset={c3 * (1 - pct * 0.70)}/>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-0.5">
        <span className="text-4xl font-black tracking-tighter leading-none"
              style={{ background: GRADIENTS.primary, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          {score}
        </span>
        <span className="text-[9px] font-semibold tracking-widest uppercase text-[#8888A8]">
          Health Score
        </span>
        <span className="text-[11px] font-medium text-[#22C55E] mt-0.5">
          ▲ {change} from yesterday
        </span>
      </div>
    </div>
  )
}

/**
 * EmptyState — zero-data screen
 */
export const EmptyState = ({ icon = '📊', title, description, action, onAction }) => (
  <div className="flex flex-col items-center justify-center py-16 px-8 text-center">
    <div className="text-5xl mb-4 opacity-60">{icon}</div>
    <h3 className="text-[18px] font-bold text-[#F0F0F8] mb-2">{title}</h3>
    <p className="text-sm text-[#8888A8] leading-relaxed mb-6 max-w-[240px]">{description}</p>
    {action && (
      <Button onClick={onAction} size="sm">{action}</Button>
    )}
  </div>
)

/**
 * LoadingShimmer — skeleton loading placeholder
 */
export const LoadingShimmer = ({ width = '100%', height = 20, rounded = 'md', className = '' }) => {
  const r = { none: '0', sm: '8px', md: '12px', lg: '16px', xl: '20px', full: '999px' }
  return (
    <div
      className={`${className}`}
      style={{
        width, height,
        borderRadius: r[rounded] || rounded,
        background: 'linear-gradient(90deg, rgba(255,255,255,0.04) 25%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.04) 75%)',
        backgroundSize: '400px 100%',
        animation: 'shimmer 1.8s linear infinite',
      }}
    />
  )
}

/**
 * Toast notification
 */
export const Toast = ({ message, type = 'success', onClose }) => {
  const configs = {
    success: { icon: '✓', color: '#22C55E', bg: 'rgba(34,197,94,0.1)', border: 'rgba(34,197,94,0.25)' },
    warning: { icon: '⚠', color: '#EAB308', bg: 'rgba(234,179,8,0.1)', border: 'rgba(234,179,8,0.25)' },
    error:   { icon: '✕', color: '#EF4444', bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.25)' },
    info:    { icon: 'ℹ', color: '#4F9CF9', bg: 'rgba(79,156,249,0.1)', border: 'rgba(79,156,249,0.25)' },
  }
  const c = configs[type]
  return (
    <div
      className="fixed top-16 left-1/2 -translate-x-1/2 z-[600]
        flex items-center gap-2 px-4 py-3 rounded-2xl
        text-sm font-medium shadow-xl"
      style={{
        background: c.bg,
        border: `1px solid ${c.border}`,
        color: c.color,
        backdropFilter: 'blur(20px)',
        animation: 'slide-down 0.3s ease-out',
      }}
    >
      <span>{c.icon}</span>
      <span>{message}</span>
      {onClose && (
        <button onClick={onClose} className="ml-2 opacity-60 hover:opacity-100">✕</button>
      )}
    </div>
  )
}

/**
 * BottomNav — mobile navigation bar
 */
export const BottomNav = ({ active = 'home', onNavigate }) => {
  const items = [
    { key: 'home',     icon: '⊞',  label: 'Home' },
    { key: 'health',   icon: '♡',  label: 'Health' },
    { key: 'workouts', icon: '◎',  label: 'Workouts' },
    { key: 'care',     icon: '✦',  label: 'Care' },
    { key: 'profile',  icon: '◯',  label: 'Profile' },
  ]
  return (
    <nav className="absolute bottom-0 left-0 right-0 h-20 border-t border-[rgba(255,255,255,0.07)]
      flex items-center justify-around pb-4 px-2"
         style={{ background: 'rgba(11,11,18,0.94)', backdropFilter: 'blur(24px)' }}>
      {items.map(item => (
        <button
          key={item.key}
          onClick={() => onNavigate?.(item.key)}
          className={`flex flex-col items-center gap-1 py-2 px-3 transition-colors duration-200
            ${active === item.key ? 'text-[#4F9CF9]' : 'text-[#55556A]'}`}
        >
          <span className="text-xl leading-none">{item.icon}</span>
          <span className="text-[10px] font-medium">{item.label}</span>
          {active === item.key && (
            <div className="w-1 h-1 rounded-full bg-[#4F9CF9] mt-0.5" />
          )}
        </button>
      ))}
    </nav>
  )
}

// ═══════════════════════════════════════════════════════════════
// SCREENS (Composite components)
// ═══════════════════════════════════════════════════════════════

/**
 * HomeScreen — main dashboard
 */
export const HomeScreen = ({ user = { name: 'Arjun', avatar: 'AJ' } }) => {
  const metrics = [
    { label: 'Heart Rate', value: 72, unit: 'bpm', icon: '❤️', color: '#EF4444', change: 'Normal', sparkData: [68, 72, 75, 80, 72, 74, 70, 72] },
    { label: 'Blood Oxygen', value: 98, unit: '%', icon: '💧', color: '#06B6D4', change: 'Excellent', sparkData: [97, 98, 98, 97, 98, 99, 98, 98] },
    { label: 'Sleep', value: 7.2, unit: 'hrs', icon: '🌙', color: '#7C6FCD', change: 'Score: 78', sparkData: [6.5, 7.0, 7.8, 6.9, 7.5, 8.0, 7.2, 7.2] },
    { label: 'Steps', value: '6,842', unit: '', icon: '👟', color: '#10B981', change: '↑ Goal: 10k', sparkData: [4200, 8100, 6500, 9200, 5800, 7400, 6842] },
  ]

  return (
    <div className="h-full overflow-y-auto bg-[#08080F] scrollbar-none">
      {/* Greeting */}
      <div className="flex items-start justify-between px-5 pt-2 pb-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            Good morning, {user.name} 👋
          </h1>
          <p className="text-sm text-[#8888A8] mt-0.5">
            Wednesday, 15 January · <span className="text-[#22C55E]">Feeling great</span>
          </p>
        </div>
        <div className="w-10 h-10 rounded-full flex items-center justify-center
          font-bold text-sm text-white shrink-0"
             style={{ background: GRADIENTS.primary }}>
          {user.avatar}
        </div>
      </div>

      {/* Health Score */}
      <div className="flex justify-center py-4">
        <HealthScoreRing score={84} change={3} />
      </div>

      {/* AI Insight */}
      <AIInsightCard
        insight="Your HRV is 8% above baseline. Great recovery overnight — your body is primed for a moderate-high intensity workout today."
        action="Start workout"
        className="mx-4 mb-3"
      />

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-2.5 mx-4 mb-3">
        {metrics.map(m => (
          <MetricCard key={m.label} {...m} gradient={null} />
        ))}
      </div>

      {/* Activity Rings */}
      <HealthRingCard
        move={{ value: 420, max: 600 }}
        exercise={{ value: 25, max: 30 }}
        stand={{ value: 8, max: 12 }}
        className="mx-4 mb-6"
      />
    </div>
  )
}

export default {
  Badge, Button, ProgressRing, ProgressBar, Sparkline,
  MetricCard, HealthRingCard, AIInsightCard, SleepStageChart,
  MedicationItem, ChatBubble, TypingIndicator, GoalCard,
  HealthScoreRing, EmptyState, LoadingShimmer, Toast,
  BottomNav, HomeScreen,
  METRIC_COLORS, GRADIENTS,
}
